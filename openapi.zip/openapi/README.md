# OpenAPI schema for iSBE

These are entry point openapi schema for iSBE submodules (e.g. `common-web`, `eligibility-web`, `enrollment-web`, `back-office-web`, `custom-web`, `user-management-web`)

- `common.yml` has all the API definitions, that are exposed via `common-web` module. It can be used in all other modules defined below.
- `eligibility.yml` has all the API definitions, that are exposed via `eligibility-web` module. This exposes all the APIs that are required for operations on eligibility application.
- `enrollment.yml` has all the API definitions, that are exposed via `enrollment-web` module.
- `back-office.yml` has all the API definitions, that are exposed via `back-office-web` module.
- `custom.yml` has all the API definitions, that are exposed via `custom-web` module.
- `user-management.yml` has all the API definitions, that are exposed via `user-management-web` module.

When all the APIs is served via a single `spring-boot` project, the combined definition shall be available on out [Swagger-UI](https://localhost:8080/isbe/swagger-ui/index.html#/). In case, Swagger-UI is disabled, the definitions shall be vailable using this URL for [iSBE OpenAPI definitions](https://localhost:8080/isbe/v3/api-docs/All).

To get the consolidated openapi defintions, there is script located at `../../docs/openapi.sh`. This can be run to create a consolidated file `../../docs/modules/ROOT/assets/attchments/isbe.yml`. This also requires db connection, using the config `../../build/build-db/db.properties`. The db connection is required to update the description, and populate it with the possible picklist values.

## Grouped OpenAPI defintions based on tags

If there is a need to get only those definitions, that are tagged for specific purposes, e.g. `Public`, `Enterprise`, or `Custom`; we can use the api-docs URL as below:

The `tag-name` in this URL `https://localhost:8080/isbe/v3/api-docs/{tag-name}`, can be replaced with values like, `Public`, `Enterprise`, or `Custom` to get the desired output.
